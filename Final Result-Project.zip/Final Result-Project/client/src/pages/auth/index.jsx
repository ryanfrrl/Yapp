import Background from "@/assets/login2.png";
import Victory from "@/assets/victory.svg";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList } from "@/components/ui/tabs"
import { TabsContent, TabsTrigger } from "@radix-ui/react-tabs";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { apiClient } from "@/lib/api-client";
import { LOGIN_ROUTE, SIGNUP_ROUTE } from "@/utils/constants";
import { useNavigate } from "react-router-dom";
import { useAppStore } from "@/store";
import logo from "@/assets/YAPP.png";


const Auth = () => {
    const navigate = useNavigate();
    const { setUserInfo } = useAppStore();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");

    const validateLogin = () => {
        if(!email.length){
            toast.error("Email is required.");
            return false;
        }
        if(!password.length){
            toast.error("Password is required.");
            return false;
        }
        return true;
    }

    const validateSignup = () => {
        if(!email.length){
            toast.error("Email is required.");
            return false;
        }
        if(!password.length){
            toast.error("Password is required.");
            return false;
        }
        if(password !=confirmPassword){
            toast.error("Password and confirm password should be same.");
            return false;
        }
        return true;
    };

    // const handleLogin = async ()=> {
    //     if(validateLogin()) {
    //         const response = await apiClient.post(LOGIN_ROUTE, { email, password }, { withCredentials: true });
    //         if(response.data.user) {
    //             setUserInfo(response.data.user);
    //             if(response.data.user.profileSetup) navigate("/chat");
    //             else navigate("/profile");
    //         }
    //         console.log({ response });
    //     }
    // };
    
    const handleLogin = async () => {
        if (validateLogin()) {
          try {
            const response = await apiClient.post(LOGIN_ROUTE, { email, password }, { withCredentials: true });
            console.log("Full Login Response:", response);
            console.log("Response Data:", response.data);
            console.log("Response Status:", response.status);
      
            if (response.data && typeof response.data === 'object') {
              if (response.data.user) {
                console.log("User Data:", response.data.user);
                setUserInfo(response.data.user);
                if (response.data.user.profileSetup) {
                  navigate("/chat");
                } else {
                  navigate("/profile");
                }
              } else if (response.data.id) {
                // If user data is not nested under 'user' key
                console.log("User Data (not nested):", response.data);
                setUserInfo(response.data);
                if (response.data.profileSetup) {
                  navigate("/chat");
                } else {
                  navigate("/profile");
                }
              } else {
                console.error("Login failed - unexpected response structure", response.data);
                toast.error("Login failed. Unexpected response from server.");
              }
            } else {
              console.error("Login failed - response.data is not an object", response.data);
              toast.error("Login failed. Invalid response from server.");
            }
          } catch (error) {
            console.error("Login error:", error);
            if (error.response) {
              console.log("Error response data:", error.response.data);
              console.log("Error response status:", error.response.status);
              toast.error(error.response.data.error || "An error occurred during login. Please try again.");
            } else {
              toast.error("An error occurred during login. Please try again.");
            }
          }
        }
      };

    const handleSignup = async () => {
        if(validateSignup()){
            const response = await apiClient.post(SIGNUP_ROUTE, { email, password }, { withCredentials: true });
            if(response.status === 201) {
                setUserInfo(response.data.user);
                navigate("/profile");
            }
            console.log({ response });
        }
    };
    
    return (
        <div className = "h-[100vh] w-[100vw] flex justify-center items-center bg-yellow-400">
            <div className = "h-[80vh] bg-white border-2 text-opacity-90 shadow-2xl w-[80vw] md:w-[90vw] lg:w-[70vw] xl:w-[50vw] rounded-2xl  items-center justify-center">
                <div className="flex h-full gap-6 xl:gap-0 md:gap-0 sm:gap-0 items-center justify-center w-full">  
                    <div className="flex w-[50vw] h-80 items-center justify-center">
                        <div className="items-center justify-center">
                            <img className="flex h-64 rounded-full object-cover justify-center" src={logo}/>
                        </div>
                    </div>
                    <div className="flex items-starter justify-start h-64  w-[40vw] rounded-3xl">
                        <Tabs className="w-4/5" defaultValue="login">
                            <TabsList className="bg-transparent rounded-non w-full"> 
                                <TabsTrigger value ="login" className="data-[state=active]:bg-transparent text-black text-opacity-90 border-b-2 rounded-none w-full data-[state=active]:text-black data-[state=active]:font-semibold data-[state=active]:border-b-yellow-500 p-3 transition-all duration-300 ">Login</TabsTrigger>
                                <TabsTrigger 
                                    value ="signup"
                                    className="data-[state=active]:bg-transparent text-black text-opacity-90 border-b-2 rounded-none w-full data-[state=active]:text-black data-[state=active]:font-semibold data-[state=active]:border-b-yellow-500 p-3 transition-all duration-300 ">Signup</TabsTrigger>
                            </TabsList>
                            <TabsContent className="flex flex-col gap-5 mt-10" value="login">
                                <Input 
                                    placeholder="Email" 
                                    type="email" 
                                    className="rounded-2xl p-5" 
                                    value={email} 
                                    onChange={(e)=>setEmail(e.target.value)}
                                />
                                <Input 
                                    placeholder="Password" 
                                    type="password" 
                                    className="rounded-2xl p-5" 
                                    value={password} 
                                    onChange={(e)=>setPassword(e.target.value)}
                                />
                                <Button className="rounded-2xl p-5" onClick={handleLogin}>
                                    Login
                                </Button>
                            </TabsContent>
                            <TabsContent 
                                className="flex flex-col gap-5" 
                                value="signup">
                                <Input 
                                    placeholder="Email" 
                                    type="email" 
                                    className="rounded-2xl p-5" 
                                    value={email} 
                                    onChange={(e)=>setEmail(e.target.value)}
                                />
                                <Input 
                                    placeholder="Password" 
                                    type="password" 
                                    className="rounded-2xl p-5" 
                                    value={password} 
                                    onChange={(e)=>setPassword(e.target.value)}
                                />
                                <Input 
                                    placeholder="Confirm Password" 
                                    type="password" 
                                    className="rounded-2xl p-5" 
                                    value={confirmPassword} 
                                    onChange={(e)=>setConfirmPassword(e.target.value)}
                                />
                                <Button className="rounded-2xl p-5" onClick={handleSignup}>
                                    Signup
                                </Button>
                            </TabsContent>
                        </Tabs>
                    </div> 
                </div>
            </div>
        </div>
    );
};

export default Auth