import { useSocket } from "@/context/SocketContext"
import { useAppStore } from "@/store"
import EmojiPicker from "emoji-picker-react"
import { useEffect, useRef, useState } from "react"
import { GrAttachment } from 'react-icons/gr'
import { IoSend } from "react-icons/io5"
import { RiEmojiStickerLine } from "react-icons/ri"


const MessageBar = () => {
    const emojiRef = useRef();
    const socket = useSocket();
    const {selectedChatType, selectedChatData, userInfo} = useAppStore();
    const [message, setMessage] = useState("");
    const [emojiPickerOpen, setEmojiPickerOpen] = useState(false);

    useEffect(() => {
        function handClickOutside(event) {
            if(emojiRef.current && !emojiRef.current.contains(event.target)) {
                setEmojiPickerOpen(false);
            }
        }
        document.addEventListener("mousedown", handClickOutside);
        return () => {
            document.removeEventListener("mousedown", handClickOutside);
        };
    }, [emojiRef]);

    const handleAddEmoji = (emoji) => {
        setMessage((msg) => msg + emoji.emoji);
    }

    const handleSendMessage = async () => {
        if (message.trim() === "") return; 
        if(selectedChatType==="contact") {
            socket.emit("sendMessage", {
                sender: userInfo.id,
                content: message,
                recipient: selectedChatData._id,
                messageType: "text",
                fileUrl: undefined,
            });
        } else if(selectedChatType =="channel") {
            socket.emit("send-channel-message",{
                sender: userInfo.id,
                content: message,
                messageType: "text",
                fileUrl: undefined,
                channelId: selectedChatData._id,
            }
            );
        }
        setMessage(""); 
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault(); // Prevent default to avoid new line
          handleSendMessage();
        }
      };
    

  return (
    <div className="h-[10vh] bg-gray-100 flex justify-center items-center px-8  gap-6">
        <div className="flex-1 flex bg-gray-100 rounded-md items-center gap-5 pr-5">
            <input
                type="text" 
                className="flex-1 p-3 bg-transparent rounded-3xl border-2 border-black" 
                placeholder="Enter Message"   
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
           />
           <button className="text-black focus:border-none focus:outline-none focus:text-white duration-300 transition-all">
                <GrAttachment className="text-2xl" />
           </button>
           <div className="realtive">
            <button className="text-black focus:border-none focus:outline-none focus:text-white duration-300 transition-all" onClick={() => setEmojiPickerOpen(true)}>
                 <RiEmojiStickerLine className="text-xl" />
            </button>
            <div className="absolute bottom-16 right-0" ref={emojiRef}>
                <EmojiPicker 
                    theme="dark"
                    open={emojiPickerOpen}
                    onEmojiClick={handleAddEmoji}
                    autoFocusSearch={false}
                />
            </div>
           </div>
        </div>
        <button className="bg-yellow-400 rounded-full flex items-center justify-center p-3.5 focus:border-none hover:bg-yellow-700 focus:bg-[741bda] focus:outline-none focus:text-white duration-300 transition-all" onClick={handleSendMessage}>
             <IoSend className="text-xl" />
        </button>
    </div>
  )
}

export default MessageBar