import { apiClient } from "@/lib/api-client";
import { useAppStore } from "@/store";
import { GET_ALL_MESSAGES_ROUTE, GET_CHANNEL_MESSAGES } from "@/utils/constants";
import moment from "moment";
import { useEffect, useRef } from "react";
import { Avatar, AvatarFallback } from "@radix-ui/react-avatar";
import { AvatarImage } from "@radix-ui/react-avatar";
import { getColor } from "@/lib/utils";
import { HOST } from "@/utils/constants";

const MessageContainer = () => {

    const scrollRef = useRef();
    const {selectedChatType, selectedChatData, userInfo, selectedChatMessages, setSelectedChatMessages,} = useAppStore();
      useEffect(() => {
        const getMessages = async () => {
          try{
            const response = await apiClient.post(GET_ALL_MESSAGES_ROUTE, {id: selectedChatData._id}, { withCredentials:true});
            if (response.data.messages) {
              setSelectedChatMessages(response.data.messages);
            }
          } catch(error) {
            console.log(error);
          }
        };

        const getChannelMessages = async ()=> {
          try{
            const response = await apiClient.get(`${GET_CHANNEL_MESSAGES}/${selectedChatData._id}`, { withCredentials:true});
            if (response.data.messages) {
              setSelectedChatMessages(response.data.messages);
            }
          } catch(error) {
            console.log(error);
          }

        }
        if(selectedChatData._id) {
          if(selectedChatType === "contact") getMessages();
          else if(selectedChatType === "channel") getChannelMessages();
        }
      }, [selectedChatData, selectedChatType, setSelectedChatMessages])

    useEffect(() => {
      if(scrollRef.current) {
        scrollRef.current.scrollIntoView({behavior:"smooth"});
      }
    }, [selectedChatMessages]);

    const renderMessages = () => {
      let lastDate = null;
      return selectedChatMessages.map((message, index) => {
        const messageDate = moment(message.timestamp).format("YYYY-MM-DD");
        const showDate = messageDate !== lastDate;
        lastDate = messageDate;
        return (
          <div key={index}>
            {showDate && (
              <div className="text-center text-black my-2">
                {moment(message.timestamp).format("LL")}
              </div>
              )}
              {
                selectedChatType === "contact" && renderDMMessages(message)
              }
              {
                selectedChatType === "channel" && renderChannelMessages(message)
              }
          </div>
        )
      });
    };

    const renderDMMessages = (message) => (
      <div 
        className={`mt-2 ${message.sender===selectedChatData._id ? "text-left":"text-right"
        }`}
      >
        {
          message.messageType ==="text" && (
            <div 
            className={`${
              message.sender !== selectedChatData._id
               ? "bg-yellow-400 text-black border-yellow-100"
               : "bg-gray-100 text-black border-[#ffffff]/20"
            }border inline-block p-4 rounded-3xl my-1 max-w-[50%] break-words`}
          >
            {message.content}
          </div>
        )}
        <div className="text-xs text-gray-600">
        {moment(message.timestamp).format("LT")}
        </div>
      </div>
    );

    const renderChannelMessages = (message)=> {
      return(
        <div className={`mt-2 ${message.sender._id !== userInfo.id ? "text-left":"text-right"

        }`}
        >
          {
          message.messageType ==="text" && (
            <div 
            className={`${
              message.sender._id === userInfo.id
               ? "bg-yellow-400 text-black border-yellow-100"
               : "bg-gray-100 text-black border-[#8417ff]/20"
            }border inline-block p-4 rounded-3xl  max-w-[50%] break-words ml-9`}
          >
            {message.content}
          </div>
        )}
        {
          message.sender._id !== userInfo.id ? <div className="flex items-center justify-start gap-3">
            <Avatar className="h-8 w-8 rounded-full overflow-hidden">
                    {
                      message.sender.image && (
                        <AvatarImage 
                        src={`${HOST}/${message.sender.image}`} 
                        alt="profile" 
                        className="object-cover w-full h-full bg-black" 
                        /> 
                      )}
                        <AvatarFallback 
                          className={`uppercase h-8 w-8 text-lg
                           items-center justify-center rounded-full
                           ${getColor(
                              message.sender.color
                              )}`}
                          >
                            {message.sender.firstName 
                            ? message.sender.firstName.split("").shift()
                            : message.sender.email.split("").shift()}
                        </AvatarFallback>
                    </Avatar>
                    <span className="text-sm text-black">{`${message.sender.firstName} ${message.sender.lastName}`}</span>
                    <span className="text-xs text-black">
                    {moment(message.timestamp).format("LT")}
                    </span>
          </div> : 
          <div className="text-xs text-black mt-1">
                    {moment(message.timestamp).format("LT")}
                    </div>
        }
        </div>
      )
    }

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hidden p-4 px-8 md:w-[65vw] lg:w-[70vw] xl:w-[80vw] w-full">
      {renderMessages()}
      <div ref={scrollRef}/>
    </div>
  );
};

export default MessageContainer